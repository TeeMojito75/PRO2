var searchData=
[
  ['actu_5fstats_0',['actu_stats',['../class_jugador.html#acb9c3c861f8b6ceb5906837b785b66dc',1,'Jugador']]],
  ['actualizar_5fenfrentamientos_1',['actualizar_enfrentamientos',['../class_torneo.html#a1e8934653d38fb4973de851d56b44c04',1,'Torneo']]],
  ['actualizar_5fjugadores_2',['actualizar_jugadores',['../class_torneo.html#a452950d3882b8b579778ee467f313f21',1,'Torneo']]],
  ['actualizar_5franking_3',['actualizar_ranking',['../class_cjt__jugadores.html#ac7930b74caf759755a254e0badafc0d3',1,'Cjt_jugadores']]],
  ['ampliar_5fparticipantes_4',['ampliar_participantes',['../class_torneo.html#a8e6b0d35b348318bc05ff35f3f87a67b',1,'Torneo']]]
];
