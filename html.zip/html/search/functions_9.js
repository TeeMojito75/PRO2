var searchData=
[
  ['nuevo_5fjugador_146',['nuevo_jugador',['../class_cjt__jugadores.html#a06e6df2ac2ddbb9cdc21b7c127fa1132',1,'Cjt_jugadores']]],
  ['nuevo_5ftorneo_147',['nuevo_torneo',['../class_cjt__torneos.html#a8ccb9ab4b028ecc8333a3c56d5f24ac9',1,'Cjt_torneos']]],
  ['num_5fjugadores_148',['num_jugadores',['../class_cjt__jugadores.html#a4951d7691e67c44415fdcb3119dd4148',1,'Cjt_jugadores::num_jugadores()'],['../class_torneo.html#a531716795208cd139642f599be82c6d9',1,'Torneo::num_jugadores()']]],
  ['num_5ftorneos_149',['num_torneos',['../class_cjt__torneos.html#aba6d57df308bdbfa173578c108e19b82',1,'Cjt_torneos']]]
];
