var searchData=
[
  ['categoria_87',['categoria',['../structcategoria.html',1,'']]],
  ['cjt_5fcategorias_88',['Cjt_categorias',['../class_cjt__categorias.html',1,'']]],
  ['cjt_5fjugadores_89',['Cjt_jugadores',['../class_cjt__jugadores.html',1,'']]],
  ['cjt_5ftorneos_90',['Cjt_torneos',['../class_cjt__torneos.html',1,'']]]
];
