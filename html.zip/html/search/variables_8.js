var searchData=
[
  ['ranking_170',['ranking',['../class_cjt__jugadores.html#a94d661595d074adf3b6ff6db8e6ee143',1,'Cjt_jugadores']]],
  ['resultados_171',['resultados',['../class_torneo.html#adb0ae255d28e1df379cb0484a5cdaf4f',1,'Torneo']]]
];
