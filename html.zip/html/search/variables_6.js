var searchData=
[
  ['n_5fparticipantes_164',['n_participantes',['../class_torneo.html#a3c124117c113604177778d95db2204b7',1,'Torneo']]],
  ['nombre_165',['nombre',['../structcategoria.html#a7a146c6f2e3726627cee04f756647ae5',1,'categoria::nombre()'],['../class_jugador.html#ae173555c513c4267f92c915e94c7e524',1,'Jugador::nombre()'],['../struct_participantes.html#afc1711b503fdc2c45218e84cb5178f49',1,'Participantes::nombre()'],['../class_torneo.html#a07a49e6996e995b550d2b803c86638ba',1,'Torneo::nombre()']]]
];
