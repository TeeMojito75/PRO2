var searchData=
[
  ['main_57',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['match_58',['match',['../struct_participantes.html#a7498e1fe34a6cd1e1b3f6f252c2020ec',1,'Participantes']]],
  ['modificar_5fnpart_59',['modificar_npart',['../class_torneo.html#a27ff3b8789d67d2044b2fb8174c3c8b9',1,'Torneo']]],
  ['modificar_5fposicion_60',['modificar_posicion',['../class_jugador.html#aec10fcab3d358d1a903ef76dfde35c23',1,'Jugador']]],
  ['modificar_5fpuntos_61',['modificar_puntos',['../class_jugador.html#a422516525af1c28803156d1d4dd30aa8',1,'Jugador']]]
];
