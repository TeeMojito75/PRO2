var searchData=
[
  ['partidos_166',['partidos',['../class_jugador.html#ad22751abd0143014747f559dcfa63d49',1,'Jugador']]],
  ['posicion_167',['posicion',['../class_jugador.html#a0c0f3be497388acec0e2c890dcd46850',1,'Jugador']]],
  ['puntos_168',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()'],['../struct_participantes.html#ab6a3a89886cb9fc065103cf781285992',1,'Participantes::puntos()']]],
  ['puntuaciones_169',['puntuaciones',['../structcategoria.html#a724663dbe9302a7c7329037e954c09c4',1,'categoria']]]
];
