var searchData=
[
  ['torneos_174',['torneos',['../class_cjt__torneos.html#a27faf8c4a4eb807a86ed2a4de8bbb71f',1,'Cjt_torneos']]],
  ['torneos_5fdisputados_175',['torneos_disputados',['../class_jugador.html#a1fb5771e4831c35b18cdc2ddf6dac2fc',1,'Jugador']]]
];
