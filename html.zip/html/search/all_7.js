var searchData=
[
  ['juegos_43',['juegos',['../class_jugador.html#ab8ea358b14201e7fad986174d0b04f16',1,'Jugador']]],
  ['jug_44',['jug',['../class_torneo.html#a928a3b1409b9f30ee4ef2d76329d6e0f',1,'Torneo']]],
  ['jugador_45',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a5b49e4daecb46709edad0200420698bc',1,'Jugador::Jugador(string nombre)']]],
  ['jugador_2ecc_46',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_47',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugadores_48',['jugadores',['../class_cjt__jugadores.html#ae3fc5f98e0f343b039bd7dff0e616ecc',1,'Cjt_jugadores']]]
];
