var searchData=
[
  ['cat_155',['cat',['../class_torneo.html#a1a93990b1100448d418b2b8ae4ff1068',1,'Torneo']]],
  ['categorias_156',['categorias',['../class_cjt__categorias.html#ace3fcdca1dd9fc59c0d5f2892d21ad34',1,'Cjt_categorias']]]
];
