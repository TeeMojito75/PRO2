var searchData=
[
  ['baja_5ftorneo_110',['baja_torneo',['../class_cjt__torneos.html#aa6e15e879932fdb8da263e9769cecfcf',1,'Cjt_torneos']]]
];
