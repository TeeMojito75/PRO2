var searchData=
[
  ['finalizar_5ftorneo_129',['finalizar_torneo',['../class_cjt__torneos.html#ae576ba30f80d7492a8a13c7ab25b6823',1,'Cjt_torneos']]]
];
