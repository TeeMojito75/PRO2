var searchData=
[
  ['salida_2etxt_126',['salida.txt',['../salida_8txt.html',1,'']]],
  ['sample_5fintermedia_2einp_127',['sample_intermedia.inp',['../sample__intermedia_8inp.html',1,'']]],
  ['sample_5fintermedia_2eout_128',['sample_intermedia.out',['../sample__intermedia_8out.html',1,'']]]
];
