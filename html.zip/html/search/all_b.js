var searchData=
[
  ['n_5fparticipantes_62',['n_participantes',['../class_torneo.html#a3c124117c113604177778d95db2204b7',1,'Torneo']]],
  ['nombre_63',['nombre',['../structcategoria.html#a7a146c6f2e3726627cee04f756647ae5',1,'categoria::nombre()'],['../class_jugador.html#ae173555c513c4267f92c915e94c7e524',1,'Jugador::nombre()'],['../struct_participantes.html#afc1711b503fdc2c45218e84cb5178f49',1,'Participantes::nombre()'],['../class_torneo.html#a07a49e6996e995b550d2b803c86638ba',1,'Torneo::nombre()']]],
  ['nuevo_5fjugador_64',['nuevo_jugador',['../class_cjt__jugadores.html#a06e6df2ac2ddbb9cdc21b7c127fa1132',1,'Cjt_jugadores']]],
  ['nuevo_5ftorneo_65',['nuevo_torneo',['../class_cjt__torneos.html#a8ccb9ab4b028ecc8333a3c56d5f24ac9',1,'Cjt_torneos']]],
  ['num_5fjugadores_66',['num_jugadores',['../class_cjt__jugadores.html#a4951d7691e67c44415fdcb3119dd4148',1,'Cjt_jugadores::num_jugadores()'],['../class_torneo.html#a531716795208cd139642f599be82c6d9',1,'Torneo::num_jugadores()']]],
  ['num_5ftorneos_67',['num_torneos',['../class_cjt__torneos.html#aba6d57df308bdbfa173578c108e19b82',1,'Cjt_torneos']]]
];
