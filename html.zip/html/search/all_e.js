var searchData=
[
  ['ranking_76',['ranking',['../class_cjt__jugadores.html#a94d661595d074adf3b6ff6db8e6ee143',1,'Cjt_jugadores']]],
  ['resultados_77',['resultados',['../class_torneo.html#adb0ae255d28e1df379cb0484a5cdaf4f',1,'Torneo']]],
  ['results_78',['results',['../class_torneo.html#ac3a1207a7d22feb41c1c4ebc9a917d11',1,'Torneo']]]
];
