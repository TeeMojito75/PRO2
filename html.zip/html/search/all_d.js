var searchData=
[
  ['quitar_5fpuntos_75',['quitar_puntos',['../class_torneo.html#a4e555b4e564592f3b6b848467e33235d',1,'Torneo']]]
];
