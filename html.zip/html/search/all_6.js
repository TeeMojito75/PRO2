var searchData=
[
  ['i_5fresults_39',['i_results',['../class_torneo.html#a6acedacc9b7cea00978c4a3f72a320f0',1,'Torneo']]],
  ['iniciar_5ftorneo_40',['iniciar_torneo',['../class_cjt__torneos.html#a6e574667b3d7365e04f8b2d2697b27a7',1,'Cjt_torneos']]],
  ['inscripciones_41',['inscripciones',['../class_torneo.html#abcd9605fb301989364fef836ef3069a9',1,'Torneo']]],
  ['inscripciones_5ft_42',['inscripciones_t',['../class_torneo.html#a9032a395eece6293cfb1902fcdbe73c7',1,'Torneo']]]
];
