var searchData=
[
  ['torneo_81',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a46afb7e6cb5dd3b827b9b5dcb6453266',1,'Torneo::Torneo()']]],
  ['torneo_2ecc_82',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_83',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['torneos_84',['torneos',['../class_cjt__torneos.html#a27faf8c4a4eb807a86ed2a4de8bbb71f',1,'Cjt_torneos']]],
  ['torneos_5fdisputados_85',['torneos_disputados',['../class_jugador.html#a1fb5771e4831c35b18cdc2ddf6dac2fc',1,'Jugador']]]
];
