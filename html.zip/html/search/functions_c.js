var searchData=
[
  ['results_153',['results',['../class_torneo.html#ac3a1207a7d22feb41c1c4ebc9a917d11',1,'Torneo']]]
];
