var searchData=
[
  ['ultima_5fed_176',['ultima_ed',['../class_torneo.html#ad253ad97ab917a206bb03bb1553a0c91',1,'Torneo']]]
];
