var searchData=
[
  ['puntos_150',['puntos',['../class_cjt__categorias.html#ab171dd65b607883a194caf1c231466e6',1,'Cjt_categorias']]],
  ['puntos_5f0_151',['puntos_0',['../class_torneo.html#ab25fa0b6dbdd6327749f5344c851c66f',1,'Torneo']]]
];
