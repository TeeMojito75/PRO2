var searchData=
[
  ['lectura_5fini_5fcat_50',['lectura_ini_cat',['../class_cjt__categorias.html#abd4602a61de779b1185c40fb87865598',1,'Cjt_categorias']]],
  ['lectura_5fini_5fjug_51',['lectura_ini_jug',['../class_cjt__jugadores.html#a851ea612923389c48d25f31e0933eb16',1,'Cjt_jugadores']]],
  ['lectura_5fini_5ftor_52',['lectura_ini_tor',['../class_cjt__torneos.html#a1bc57bfbe9baa962f4502316629735e2',1,'Cjt_torneos']]],
  ['listar_5fcategorias_53',['listar_categorias',['../class_cjt__categorias.html#a14842f3c922d4dd130224f57ead4f3cb',1,'Cjt_categorias']]],
  ['listar_5fjugadores_54',['listar_jugadores',['../class_cjt__jugadores.html#a12a21975f2ae944bd24c7a6722bad32c',1,'Cjt_jugadores']]],
  ['listar_5franking_55',['listar_ranking',['../class_cjt__jugadores.html#ac2b9b5e383120066310e98d880ac7fcd',1,'Cjt_jugadores']]],
  ['listar_5ftorneos_56',['listar_torneos',['../class_cjt__torneos.html#ae2f7998d6771a04591d226299966551b',1,'Cjt_torneos']]]
];
