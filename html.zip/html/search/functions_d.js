var searchData=
[
  ['torneo_154',['Torneo',['../class_torneo.html#a46afb7e6cb5dd3b827b9b5dcb6453266',1,'Torneo']]]
];
