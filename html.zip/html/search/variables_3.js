var searchData=
[
  ['juegos_159',['juegos',['../class_jugador.html#ab8ea358b14201e7fad986174d0b04f16',1,'Jugador']]],
  ['jug_160',['jug',['../class_torneo.html#a928a3b1409b9f30ee4ef2d76329d6e0f',1,'Torneo']]],
  ['jugadores_161',['jugadores',['../class_cjt__jugadores.html#ae3fc5f98e0f343b039bd7dff0e616ecc',1,'Cjt_jugadores']]]
];
