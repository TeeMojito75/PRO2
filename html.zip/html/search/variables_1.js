var searchData=
[
  ['enfrentamientos_157',['enfrentamientos',['../class_torneo.html#abb8a79a6205d5e7ff35f59bf285a49ab',1,'Torneo']]]
];
