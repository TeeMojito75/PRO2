var searchData=
[
  ['set_172',['set',['../struct_participantes.html#a571c6a45783186a8bf858e97e3d43080',1,'Participantes']]],
  ['sets_173',['sets',['../class_jugador.html#a0f820a9a62c75c9104ac759c48a2219b',1,'Jugador']]]
];
